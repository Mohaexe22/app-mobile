import 'package:flutter/material.dart';

const size5 = SizedBox(height: 50);
const SizeG = SizedBox(height: 220);

const tes1 = Text(
  "please obtain your information from the administration",
  maxLines: 2,
  style: TextStyle(fontSize: 14),
);
const ConColor = Color(0x685E6E);
const Scolor = Color.fromARGB(0, 69, 48, 69);
